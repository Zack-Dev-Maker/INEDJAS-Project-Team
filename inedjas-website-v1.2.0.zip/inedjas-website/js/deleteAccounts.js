import { showToast } from "./auth.js";

let deleteCallback = null; // guardamos qué hacer al confirmar

function openConfirmModal(message, onConfirm) {
  document.getElementById("confirmDeleteMessage").textContent = message;
  document.getElementById("confirmDeleteModal").classList.remove("hidden");
  deleteCallback = onConfirm;
}

function closeConfirmModal() {
  document.getElementById("confirmDeleteModal").classList.add("hidden");
  deleteCallback = null;
}

// Inicializar listeners del modal
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("cancelDeleteBtn")?.addEventListener("click", closeConfirmModal);
  document.getElementById("confirmDeleteBtn")?.addEventListener("click", () => {
    if (deleteCallback) deleteCallback();
    closeConfirmModal();
  });
});

export function initDeleteAccounts() {
  const container = document.getElementById("accountsContainer");
  const heroUsername = document.getElementById("heroUsername");

  let currentUser = JSON.parse(localStorage.getItem("currentUser")) || { username: "Invitado" };
  heroUsername.textContent = currentUser.username;

  let users = JSON.parse(localStorage.getItem("users")) || {};

  // Normalizar formato
  if (!Array.isArray(users)) {
    users = Object.entries(users).map(([username, data]) => ({
      username,
      ...data,
      role: Array.isArray(data.role) ? data.role : [data.role]
    }));
  }

  const allRoles = ["Admin", "Dev", "Docente", "Estudiante"];
  const roles = {};
  allRoles.forEach(r => (roles[r] = []));

  users.forEach(user => {
    user.role.forEach(r => {
      if (!roles[r]) roles[r] = [];
      roles[r].push(user);
    });
  });

  container.innerHTML = "";

  allRoles.forEach(role => {
    const section = document.createElement("section");
    section.className = "bg-white p-6 rounded-xl shadow-lg";

    const title = document.createElement("h2");
    title.className = "text-xl font-semibold mb-4 text-gray-800";
    title.textContent = `Rol: ${role}`;
    section.appendChild(title);

    const list = document.createElement("ul");
    list.className = "space-y-2";

    if (roles[role].length === 0) {
      const emptyMsg = document.createElement("p");
      emptyMsg.className = "text-gray-500 text-sm";
      emptyMsg.textContent = "No hay cuentas en este rol.";
      section.appendChild(emptyMsg);
    } else {
      roles[role].forEach(user => {
        const li = document.createElement("li");
        li.className = "flex justify-between items-center p-3 bg-gray-100 rounded-lg";

        const avatar = user.avatar || "../assets/user_default.png";

        li.innerHTML = `
          <div class="flex items-center gap-3">
            <img src="${avatar}" alt="Avatar" class="w-8 h-8 rounded-full object-cover border border-gray-300">
          <span class="font-medium">${user.username}</span>
          </div>
          <button class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-lg text-sm">
            Eliminar
          </button>
        `;

        const btn = li.querySelector("button");

        if (user.username === "MonoDev2025" && user.role.includes("Admin") && user.role.includes("Dev")) {
          btn.disabled = true;
          btn.classList.add("opacity-50", "cursor-not-allowed");
          btn.textContent = "Protegida";
        } else {
          btn.addEventListener("click", () => {
            openConfirmModal(
              `¿Eliminar la cuenta "${user.username}"?`,
              () => {
                users = users.filter(u => u.username !== user.username);
                localStorage.setItem("users", JSON.stringify(users.reduce((acc, u) => {
                  acc[u.username] = { ...u, username: undefined };
                  return acc;
                }, {})));

                li.remove();
                showToast(`Cuenta "${user.username}" eliminada.`, "success");
              }
            );
          });
        }

        list.appendChild(li);
      });
      section.appendChild(list);
    }

    container.appendChild(section);
  });
}
