// ========== ✅ SISTEMA DE TOASTS ==========
export function showToast(message, type = "info") {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.className = "fixed top-5 center-5 z-[9999] flex flex-col gap-2";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `
    px-4 py-2 rounded-lg shadow-md text-white animate-fade-in-down
    ${type === "success" ? "bg-green-600" : ""}
    ${type === "error" ? "bg-red-600" : ""}
    ${type === "warning" ? "bg-yellow-500 text-black" : ""}
    ${type === "info" ? "bg-blue-600" : ""}
  `;
  toast.innerText = message;

  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("animate-fade-out");
    setTimeout(() => toast.remove(), 500);
  }, 3000);
}

// ========== ✅ CUENTAS DEV POR DEFECTO ==========
function ensureDevAccounts() {
  const users = JSON.parse(localStorage.getItem("users") || "{}");

  const devAccounts = {
    "MonoDev2025": "proyectoINEDJAS",
    "KenjiroBarros": "proyectoINEDJAS",
    "EndersonCervera": "proyectoINEDJAS",
    "MariaMarin": "proyectoINEDJAS",
  };

  for (const [username, password] of Object.entries(devAccounts)) {
    if (!users[username]) {
      users[username] = { password, role: ["Dev"] };
    } else if (username === "MonoDev2025") {
      const currentRoles = Array.isArray(users[username].role) ? users[username].role : [users[username].role];
      if (!currentRoles.includes("Dev")) currentRoles.push("Dev");
      if (!currentRoles.includes("Admin")) currentRoles.push("Admin");
      users[username].role = currentRoles;
    }
  }

  localStorage.setItem("users", JSON.stringify(users));
}
ensureDevAccounts();

// ========== Helper para redirigir ==========
function goToIndex() {
  const isInRoot = !window.location.pathname.includes("/pages/");
  window.location.href = isInRoot ? "index.html" : "../index.html";
}

// ========== ✅ LOGIN ==========
export function login() {
  const username = document.getElementById("login-username")?.value.trim();
  const password = document.getElementById("login-password")?.value.trim();

  if (!username || !password) {
    showToast("Por favor, completa todos los campos.", "warning");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users") || "{}");
  const userData = users[username];

  if (userData && userData.password === password) {
    const roles = Array.isArray(userData.role) ? userData.role : [userData.role];
    const user = { username, role: roles };
    localStorage.setItem("currentUser", JSON.stringify(user));
    showToast(`¡Bienvenido, ${username}!`, "success");
    window.location.href = "pages/home.html";
  } else {
    showToast("Usuario o contraseña incorrectos.", "error");
  }
}

// ========== ✅ Helpers de registro ==========
export function validarCC(docNumber) {
  if (!/^\d+$/.test(docNumber)) return { valido: false, mensaje: "El documento solo debe contener números." };

  const length = docNumber.length;

  if (length >= 7 && length <= 8) return { valido: true, tipo: "CC_vieja" };
  if (length >= 9 && length <= 10) return { valido: true, tipo: "CC_nueva" };

  return { valido: false, mensaje: "Cédula de ciudadanía inválida." };
}

function validarDocumentoAvanzado(docNumber, role) {
  switch (role) {
    case "Estudiante":
      if (!/^\d+$/.test(docNumber)) return "El documento solo debe contener números.";
      if (docNumber.length !== 10) return "Un estudiante debe registrarse con Tarjeta de Identidad (10 dígitos).";
      break;
    case "Docente":
    case "Admin":
    case "Dev":
      const ccCheck = validarCC(docNumber);
      if (!ccCheck.valido && (docNumber.length < 7 || docNumber.length > 11)) {
        return "Debe ingresar un documento válido (CC vieja/nueva o CE).";
      }
      break;
    default:
      return "Rol no válido para registro.";
  }
  return null;
}

function obtenerTipoDocumento(docNumber, role) {
  if (role === "Estudiante") return "TI";
  if (role === "Docente" || role === "Admin" || role === "Dev") {
    const ccCheck = validarCC(docNumber);
    if (ccCheck.valido) return ccCheck.tipo; // CC_vieja o CC_nueva
    return "CE";
  }
  return "Desconocido";
}

// ========== ✅ REGISTER ==========
export function register() {
  const currentUser = JSON.parse(localStorage.getItem("currentUser") || "null");
  const currentRoles = Array.isArray(currentUser?.role) ? currentUser.role : [currentUser?.role];

  if (!currentUser || !currentRoles.some(r => ["Admin", "Dev"].includes(r))) {
    showToast("Solo un Admin o Dev puede crear cuentas nuevas.", "error");
    return;
  }

  const username = document.getElementById("register-username")?.value.trim();
  const password = document.getElementById("register-password")?.value.trim();
  const role = document.getElementById("register-role")?.value;
  const docNumber = document.getElementById("register-doc")?.value.trim();

  if (!username || !password || !role || !docNumber) {
    showToast("Por favor, completa todos los campos.", "warning");
    return;
  }

  if (username.length < 4) {
    showToast("El usuario debe tener al menos 4 caracteres.", "warning");
    return;
  }
  if (password.length < 6) {
    showToast("La contraseña debe tener mínimo 6 caracteres.", "warning");
    return;
  }

  const errorDoc = validarDocumentoAvanzado(docNumber, role);
  if (errorDoc) {
    showToast(errorDoc, "error");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users") || "{}");

  if (users[username]) {
    showToast("Ese usuario ya existe.", "error");
    return;
  }

  for (const user of Object.values(users)) {
    if (user.docNumber === docNumber) {
      showToast("Ese número de documento ya está registrado.", "error");
      return;
    }
  }

  const tipoDoc = obtenerTipoDocumento(docNumber, role);
  users[username] = { password, role: [role], docNumber, tipoDoc };
  localStorage.setItem("users", JSON.stringify(users));

  showToast(`¡Cuenta '${username}' creada con éxito por ${currentUser.username}!`, "success");

  import("./dom.js").then(mod => {
    if (typeof mod.mostrarLogin === "function") mod.mostrarLogin();
  });
}

// ========== ✅ RECUPERAR / RESETEAR CONTRASEÑA ==========
export function recoverPassword() {
  showToast("Función de recuperación de contraseña aún no implementada.", "info");
}
export function resetPassword() {
  showToast("Función de restablecimiento de contraseña aún no implementada.", "info");
}
