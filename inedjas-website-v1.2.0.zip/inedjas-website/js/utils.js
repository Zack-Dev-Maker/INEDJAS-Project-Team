// ==========================
// utils.js - Noticias/Comunicados
// ==========================

// ==========================
// Noticias
// ==========================

// Contenedor donde se mostrarán las noticias
function getNewsContainer() {
  return document.getElementById("news-container");
}

// Noticias guardadas en LocalStorage o [] si no hay
let storedNews = JSON.parse(localStorage.getItem("newsList")) || [];

// ⚡ Noticia de ejemplo si no hay ninguna guardada
if (storedNews.length === 0) {
  storedNews = [
    {
      title: "Reunión de Padres - Septiembre",
      content: "Se invita cordialmente a los padres de familia a la reunión general el próximo viernes 15 de septiembre a las 7:30 a.m. en el auditorio principal.",
      category: "aviso",
      timestamp: new Date("2025-08-20T10:00:00").getTime()
    },
    {
      title: "Batalla de Boyacá (7/08/1819) - Acto Cívico",
      content: "El día 6 de agosto se celebró un Acto Cívico de la Batalla de Boyacá, un enfrentamiento clave en la Guerra de Independencia de Colombia.",
      category: "evento",
      timestamp: new Date("2025-08-06T10:00:00").getTime()
    }
  ];
  
  saveNews();
}

// ==========================
// Comunicados
// ==========================

export const communicationsContainer = document.getElementById("communications-container");

export const communications = [
  {
    id: 1,
    title: "Reunión de padres de familia",
    description: "Se convoca a todos los padres de grado 11 a reunión este viernes.",
    date: "2025-08-25",
    category: "general"
  },
  {
    id: 2,
    title: "Pago de matrícula",
    description: "Recuerda que el plazo máximo para el pago es el 30 de septiembre.",
    date: "2025-08-20",
    category: "financiero"
  },
  {
    id: 3,
    title: "Entrega de boletines",
    description: "Los boletines estarán disponibles a partir del 1 de octubre.",
    date: "2025-08-22",
    category: "academico"
  }
];

// ==========================
// Helpers
// ==========================

function saveNews() {
  localStorage.setItem("newsList", JSON.stringify(storedNews));
}

// Colores de categorías para noticias
const CATEGORY_COLORS = {
  general: "border-blue-400 bg-blue-50 text-blue-700",
  aviso: "border-yellow-400 bg-yellow-50 text-yellow-700",
  evento: "border-green-400 bg-green-50 text-green-700",
  reporte: "border-purple-400 bg-purple-50 text-purple-700"
};

// ==========================
// Noticias - Componentes
// ==========================

export function createNewsCard({ title, content, category, timestamp }) {
  const colorClass = CATEGORY_COLORS[category] || CATEGORY_COLORS.general;

  const date = new Date(timestamp).toLocaleDateString("es-CO", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });

  const card = document.createElement("article");
  card.className = `bg-white p-5 border rounded-lg shadow-sm hover:shadow-md transition border-l-4`;
  card.dataset.category = category;

  card.innerHTML = `
    <span class="inline-block text-xs px-2 py-1 rounded ${colorClass} mb-2 font-medium">
      ${category.toUpperCase()}
    </span>
    <h4 class="font-semibold text-gray-800 mb-1">${title}</h4>
    <p class="text-sm text-gray-600">${content}</p>
    <span class="text-xs text-gray-500 block mt-2">Publicado el ${date}</span>
  `;

  return card;
}

export function renderNews(list = storedNews) {
  const newsContainer = getNewsContainer();
  if (!newsContainer) return;

  const emptyState = document.getElementById("empty-state");
  newsContainer.innerHTML = "";

  if (list.length === 0) {
    if (emptyState) emptyState.classList.remove("hidden");
    return;
  }

  if (emptyState) emptyState.classList.add("hidden");

  const sortedNews = [...list].sort((a, b) => b.timestamp - a.timestamp);
  sortedNews.forEach(news => newsContainer.appendChild(createNewsCard(news)));
}

export function initNewsForm(showToast) {
  const newsForm = document.getElementById("newsForm");
  if (!newsForm) return;

  newsForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const title = document.getElementById("newsTitle")?.value.trim();
    const content = document.getElementById("newsContent")?.value.trim();
    const category = document.getElementById("newsCategory")?.value;

    if (!title || !content) {
      showToast("Por favor, completa todos los campos.", "error");
      return;
    }

    const newEntry = {
      title,
      content,
      category: categoryMapping(category),
      timestamp: Date.now()
    };

    storedNews.unshift(newEntry);
    saveNews();
    renderNews();
    newsForm.reset();
    showToast("✅ ¡Noticia publicada con éxito!", "success");
  });
}

// Mapea valores del select del formulario a categorías internas
function categoryMapping(value) {
  switch(value) {
    case "blue": return "general";
    case "orange": return "aviso";
    case "green": return "evento";
    case "purple": return "reporte";
    default: return "general";
  }
}

// ==========================
// Filtros
// ==========================
export function setupNewsFilters() {
  const buttons = document.querySelectorAll(".filter-btn");
  buttons.forEach(btn => {
    btn.addEventListener("click", () => {
      const category = btn.dataset.category;
      if (category === "all") {
        renderNews();
      } else {
        const filtered = storedNews.filter(n => n.category === category);
        renderNews(filtered);
      }
    });
  });
}

// Función global para el botón "Mostrar todas"
window.resetFilters = () => renderNews();

// ==========================
// Comunicados - Componentes
// ==========================
export function renderCommunications(list = communications) {
  if (!communicationsContainer) return;

  communicationsContainer.innerHTML = "";

  if (!list.length) {
    communicationsContainer.innerHTML = `
      <p class="text-gray-500 text-center italic">
        📄 Actualmente no hay comunicados disponibles.
      </p>`;
    return;
  }

  list.forEach(comm => {
    const card = document.createElement("div");
    card.className = "bg-white rounded-lg shadow hover:shadow-lg transition p-5 flex flex-col";

    card.innerHTML = `
      <h3 class="text-lg font-bold text-blue-800 mb-2">${comm.title}</h3>
      <p class="text-gray-600 flex-grow">${comm.description}</p>
      <div class="mt-4 flex justify-between items-center text-sm text-gray-500">
        <span>${new Date(comm.date).toLocaleDateString("es-CO")}</span>
        <span class="capitalize">${comm.category}</span>
      </div>
    `;

    communicationsContainer.appendChild(card);
  });
}

export function setupCommunicationFilters() {
  const buttons = document.querySelectorAll(".filter-btn");
  buttons.forEach(btn => {
    btn.addEventListener("click", () => {
      const category = btn.dataset.category;
      if (category === "all") {
        renderCommunications();
      } else {
        const filtered = communications.filter(c => c.category === category);
        renderCommunications(filtered);
      }
    });
  });
}
