import { validarCC } from "./auth.js"; // 🔑 Importamos la función desde auth.js

/**
 * Muestra el formulario de registro y oculta el de login con animación
 */
export function mostrarRegistro() {
  const login = document.getElementById("login-section");
  const registro = document.getElementById("register-section");

  if (!login || !registro) {
    console.warn("⚠️ No se encontraron las secciones de login o registro.");
    return;
  }

  login.classList.add("fade-out");
  setTimeout(() => {
    login.classList.add("hidden");
    registro.classList.remove("hidden", "fade-out");
    registro.classList.add("fade-in");

    // 🔹 Inicializamos el helper visual del tipo de documento al mostrar registro
    initTipoDocumentoVisual();
  }, 300);
}

/**
 * Muestra el formulario de login y oculta el de registro con animación
 */
export function mostrarLogin() {
  const login = document.getElementById("login-section");
  const registro = document.getElementById("register-section");

  if (!login || !registro) {
    console.warn("⚠️ No se encontraron las secciones de login o registro.");
    return;
  }

  registro.classList.add("fade-out");
  setTimeout(() => {
    registro.classList.add("hidden");
    login.classList.remove("hidden", "fade-out");
    login.classList.add("fade-in");
  }, 300);
}

/**
 * Renderiza la información del usuario logueado
 * @param {Object} currentUser - Objeto con los datos del usuario
 * @param {string} currentUser.username - Nombre de usuario
 * @param {string} currentUser.role - Rol del usuario
 */
export function renderUserInfo(currentUser) {
  const usernameSpan = document.getElementById("username");
  const roleSpan = document.getElementById("userRole");
  const roleChangeSection = document.getElementById("role-change-section");

  if (!usernameSpan || !roleSpan) {
    console.warn("⚠️ No se encontraron los elementos para mostrar usuario y rol.");
    return;
  }

  if (!currentUser) {
    usernameSpan.textContent = "Invitado";
    roleSpan.textContent = "Sin rol";

    if (roleChangeSection) roleChangeSection.classList.add("hidden");
    return;
  }

  usernameSpan.textContent = currentUser.username || "Desconocido";
  roleSpan.textContent = currentUser.role || "Sin rol";

  // 🔑 Solo Admin o Dev pueden ver el panel de cambio de rol
  if (roleChangeSection) {
    if (currentUser.role === "Admin" || currentUser.role === "Dev") {
      roleChangeSection.classList.remove("hidden");
    } else {
      roleChangeSection.classList.add("hidden");
    }
  }
}

/**
 * 🔹 Helper visual para mostrar el tipo de documento en tiempo real
 */
function initTipoDocumentoVisual() {
  const docInput = document.getElementById("register-doc");
  const roleSelect = document.getElementById("register-role");

  if (!docInput || !roleSelect) return;

  // Crear label si no existe
  let tipoLabel = document.getElementById("tipo-doc-label");
  if (!tipoLabel) {
    tipoLabel = document.createElement("span");
    tipoLabel.id = "tipo-doc-label";
    tipoLabel.style.marginLeft = "10px";
    tipoLabel.style.fontWeight = "bold";
    docInput.parentNode.appendChild(tipoLabel);
  }

  const actualizarTipo = () => {
    const role = roleSelect.value;
    const docNumber = docInput.value.trim();
    if (!role || !docNumber) {
      tipoLabel.innerText = "";
      return;
    }

    let tipo = "Desconocido";
    if (role === "Estudiante") tipo = "TI";
    else if (role === "Docente" || role === "Admin" || role === "Dev") {
      const ccCheck = validarCC(docNumber);
      tipo = ccCheck.valido ? ccCheck.tipo : "CE";
    }

    tipoLabel.innerText = `Tipo: ${tipo}`;
    tipoLabel.style.color = tipo.includes("CC") ? "green" : tipo === "TI" ? "blue" : "orange";
  };

  docInput.addEventListener("input", actualizarTipo);
  roleSelect.addEventListener("change", actualizarTipo);
}
