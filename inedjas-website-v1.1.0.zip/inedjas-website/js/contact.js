// 📩 Inicialización del formulario de contacto
export function initContactForm() {
  const contactForm = document.getElementById("contactForm");
  const formMessage = document.getElementById("formMessage");

  if (!contactForm) {
    console.warn("⚠️ No se encontró el formulario de contacto en esta página.");
    return;
  }

  if (!formMessage) {
    console.warn("⚠️ No se encontró el contenedor de mensaje del formulario.");
    return;
  }

  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();

    // Validación básica de campos obligatorios
    const nombre = contactForm.querySelector("[name='nombre']")?.value.trim();
    const email = contactForm.querySelector("[name='email']")?.value.trim();
    const mensaje = contactForm.querySelector("[name='mensaje']")?.value.trim();

    if (!nombre || !email || !mensaje) {
      alert("Por favor, completa todos los campos antes de enviar.");
      return;
    }

    // Simulación de envío exitoso
    contactForm.reset();
    formMessage.textContent = "✅ Mensaje enviado correctamente.";
    formMessage.classList.remove("hidden");

    // Ocultar mensaje después de 4 segundos
    setTimeout(() => {
      formMessage.classList.add("hidden");
    }, 4000);
  });
}