import { showToast } from "./auth.js";

export function initSettings() {
  // --- Perfil (mostrar datos actuales) ---
  const usernameField = document.getElementById("usernameField");
  const roleField = document.getElementById("roleField");
  const profileImagePreview = document.getElementById("profileImagePreview");
  const profileImageUpload = document.getElementById("profileImageUpload");

  // Leer usuario actual
  let currentUser = JSON.parse(localStorage.getItem("currentUser")) || {
    username: "Invitado",
    role: "Sin rol",
  };

  let allUsers = JSON.parse(localStorage.getItem("users")) || {};

  // Mostrar datos actuales
  usernameField.value = currentUser.username;
  roleField.value = Array.isArray(currentUser.role)
    ? currentUser.role.join(", ")
    : currentUser.role;

  if (currentUser.avatar) {
    profileImagePreview.src = currentUser.avatar;
  }

  // --- Subir nueva imagen ---
  profileImageUpload.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64Image = reader.result;

      // Guardar en currentUser
      currentUser.avatar = base64Image;
      localStorage.setItem("currentUser", JSON.stringify(currentUser));

      // Guardar en users también
      if (allUsers[currentUser.username]) {
        allUsers[currentUser.username].avatar = base64Image;
        localStorage.setItem("users", JSON.stringify(allUsers));
      }

      // Mostrar en preview
      profileImagePreview.src = base64Image;
      showToast("✅ Foto de perfil actualizada", "success");
    };

    reader.readAsDataURL(file);
  });

  // --- Preferencias ---
  const darkModeToggle = document.getElementById("darkModeToggle");
  const languageSelect = document.getElementById("languageSelect");

  const preferences = JSON.parse(localStorage.getItem("preferences")) || {
    darkMode: false,
    language: "es",
  };

  darkModeToggle.checked = preferences.darkMode;
  languageSelect.value = preferences.language;

  document.documentElement.classList.toggle("dark", preferences.darkMode);

  darkModeToggle.addEventListener("change", () => {
    preferences.darkMode = darkModeToggle.checked;
    localStorage.setItem("preferences", JSON.stringify(preferences));
    document.documentElement.classList.toggle("dark", darkModeToggle.checked);

    showToast(
      `Modo ${darkModeToggle.checked ? "oscuro" : "claro"} activado`,
      "success"
    );
  });

  languageSelect.addEventListener("change", () => {
    preferences.language = languageSelect.value;
    localStorage.setItem("preferences", JSON.stringify(preferences));
    showToast(`Idioma cambiado a: ${preferences.language}`, "success");
  });

  // --- Seguridad ---
  const securityForm = document.getElementById("securityForm");
  securityForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const newPassword = document.getElementById("newPassword").value;

    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}/.test(newPassword)) {
      showToast(
        "La contraseña debe tener mayúscula, minúscula y número.",
        "error"
      );
      return;
    }

    currentUser.password = newPassword;
    localStorage.setItem("currentUser", JSON.stringify(currentUser));

    showToast("✅ Contraseña actualizada correctamente.", "success");
    securityForm.reset();
  });
}
