// ==========================
// utils.js - Noticias/Comunicados
// ==========================

// ==========================
// Noticias
// ==========================

function getNewsContainer() {
  return document.getElementById("news-container");
}

let storedNews = JSON.parse(localStorage.getItem("newsList")) || [];

if (storedNews.length === 0) {
  storedNews = [
    {
      title: "Reunión de Padres - Septiembre",
      content:
        "Se invita cordialmente a los padres de familia a la reunión general el próximo viernes 15 de septiembre a las 7:30 a.m. en el auditorio principal.",
      category: "aviso",
      timestamp: new Date("2025-08-20T10:00:00").getTime(),
    },
    {
      title: "Batalla de Boyacá (7/08/1819) - Acto Cívico",
      content:
        "El día 6 de agosto se celebró un Acto Cívico de la Batalla de Boyacá, un enfrentamiento clave en la Guerra de Independencia de Colombia.",
      category: "evento",
      timestamp: new Date("2025-08-06T10:00:00").getTime(),
    },
    {
      title: "Informe Trimestral de Calificaciones",
      content: "Ya están disponibles los reportes del primer trimestre para consulta en el portal de estudiantes.",
      category: "reporte",
      timestamp: new Date("2025-09-06T12:00:00").getTime(),
    },
  ];
  saveNews();
}

function saveNews() {
  localStorage.setItem("newsList", JSON.stringify(storedNews));
}

const CATEGORY_COLORS = {
  general: "border-blue-400 bg-blue-50 text-blue-700",
  aviso: "border-yellow-400 bg-yellow-50 text-yellow-700",
  evento: "border-green-400 bg-green-50 text-green-700",
  reporte: "border-purple-400 bg-purple-50 text-purple-700",
};

export function createNewsCard({ title, content, category, timestamp }) {
  const colorClass = CATEGORY_COLORS[category] || CATEGORY_COLORS.general;
  const date = new Date(timestamp).toLocaleDateString("es-CO", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const card = document.createElement("article");
  card.className =
    "bg-white p-5 border rounded-lg shadow-sm hover:shadow-md transition border-l-4";
  card.dataset.category = category;

  card.innerHTML = `
    <span class="inline-block text-xs px-2 py-1 rounded ${colorClass} mb-2 font-medium">
      ${category.toUpperCase()}
    </span>
    <h4 class="font-semibold text-gray-800 mb-1">${title}</h4>
    <p class="text-sm text-gray-600">${content}</p>
    <span class="text-xs text-gray-500 block mt-2">Publicado el ${date}</span>
  `;

  return card;
}

export function renderNews(list = storedNews) {
  const newsContainer = getNewsContainer();
  if (!newsContainer) return;

  const emptyState = document.getElementById("empty-news");
  newsContainer.innerHTML = "";

  // Mostrar empty solo si la lista actual está vacía
  if (!list || list.length === 0) {
    if (emptyState) emptyState.classList.remove("hidden");
    return;
  } else {
    if (emptyState) emptyState.classList.add("hidden");
  }

  const sortedNews = [...list].sort((a, b) => b.timestamp - a.timestamp);
  sortedNews.forEach((news) =>
    newsContainer.appendChild(createNewsCard(news))
  );
}

export function initNewsForm(showToast) {
  const newsForm = document.getElementById("newsForm");
  if (!newsForm) return;

  newsForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const title = document.getElementById("newsTitle")?.value.trim();
    const content = document.getElementById("newsContent")?.value.trim();
    const category = document.getElementById("newsCategory")?.value;

    if (!title || !content) {
      showToast("❌ Por favor, completa todos los campos.", "error");
      return;
    }

    const newEntry = {
      title,
      content,
      category: categoryMapping(category),
      timestamp: Date.now(),
    };

    storedNews.unshift(newEntry);
    saveNews();
    renderNews();
    newsForm.reset();
    showToast("✅ ¡Noticia publicada con éxito!", "success");
  });
}

function categoryMapping(value) {
  switch (value) {
    case "blue":
      return "general";
    case "orange":
      return "aviso";
    case "green":
      return "evento";
    case "purple":
      return "reporte"; 
    default:
      return "general";
  }
}

export function setupNewsFilters() {
  const buttons = document.querySelectorAll(".filter-btn[data-type='news']");
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const category = btn.dataset.category;
      if (category === "all") {
        renderNews();
      } else {
        const filtered = storedNews.filter((n) => n.category === category);
        renderNews(filtered);
      }
    });
  });
}

// Reset exclusivo de noticias
window.resetNewsFilters = () => renderNews();

// ==========================
// Comunicados
// ==========================

export const communicationsContainer = document.getElementById(
  "communications-container"
);

let storedCommunications =
  JSON.parse(localStorage.getItem("communicationsList")) || [];

if (storedCommunications.length === 0) {
  storedCommunications = [
    {
      id: Date.now(),
      title: "Reunión de padres de familia",
      description:
        "Se convoca a todos los padres de grado 11 a reunión este viernes.",
      date: new Date("2025-08-25").toISOString(),
      category: "general",
    },
    {
      id: Date.now() + 1,
      title: "Pago de matrícula",
      description:
        "Recuerda que el plazo máximo para el pago es el 30 de septiembre.",
      date: new Date("2025-08-20").toISOString(),
      category: "financiero",
    },
  ];
  saveCommunications();
}

function saveCommunications() {
  localStorage.setItem(
    "communicationsList",
    JSON.stringify(storedCommunications)
  );
}

const COMM_CATEGORY_COLORS = {
  general: "border-blue-400 bg-blue-50 text-blue-700",
  academico: "border-yellow-400 bg-yellow-50 text-yellow-700",
  financiero: "border-green-400 bg-green-50 text-green-700",
};

export function createCommunicationCard({
  title,
  description,
  category,
  date,
}) {
  const colorClass =
    COMM_CATEGORY_COLORS[category] || COMM_CATEGORY_COLORS.general;

  const formattedDate = new Date(date).toLocaleDateString("es-CO", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const card = document.createElement("article");
  card.className =
    "bg-white p-5 border rounded-lg shadow-sm hover:shadow-md transition border-l-4";
  card.dataset.category = category;

  card.innerHTML = `
    <span class="inline-block text-xs px-2 py-1 rounded ${colorClass} mb-2 font-medium">
      ${category.toUpperCase()}
    </span>
    <h4 class="font-semibold text-gray-800 mb-1">${title}</h4>
    <p class="text-sm text-gray-600">${description}</p>
    <span class="text-xs text-gray-500 block mt-2">Publicado el ${formattedDate}</span>
  `;

  return card;
}

export function renderCommunications(list = storedCommunications) {
  if (!communicationsContainer) return;

  const emptyState = document.getElementById("empty-comm");
  communicationsContainer.innerHTML = "";

  // Mostrar empty solo si la lista actual está vacía
  if (!list || list.length === 0) {
    if (emptyState) emptyState.classList.remove("hidden");
    return;
  } else {
    if (emptyState) emptyState.classList.add("hidden");
  }

  const sorted = [...list].sort((a, b) => new Date(b.date) - new Date(a.date));
  sorted.forEach((comm) =>
    communicationsContainer.appendChild(createCommunicationCard(comm))
  );
}

export function initCommunicationsForm(showToast) {
  const commForm = document.getElementById("communicationsForm");
  if (!commForm) return;

  commForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const title = document.getElementById("commTitle")?.value.trim();
    const description = document
      .getElementById("commDescription")
      ?.value.trim();
    const category = document.getElementById("commCategory")?.value;

    if (!title || !description) {
      showToast("❌ Por favor, completa todos los campos.", "error");
      return;
    }

    const newComm = {
      id: Date.now(),
      title,
      description,
      category,
      date: new Date().toISOString(),
    };

    storedCommunications.unshift(newComm);
    saveCommunications();
    renderCommunications();
    commForm.reset();
    showToast("✅ ¡Comunicado publicado con éxito!", "success");
  });
}

export function setupCommunicationFilters() {
  const buttons = document.querySelectorAll(
    ".filter-btn[data-type='communications']"
  );
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const category = btn.dataset.category;
      if (category === "all") {
        renderCommunications();
      } else {
        const filtered = storedCommunications.filter(
          (c) => c.category === category
        );
        renderCommunications(filtered);
      }
    });
  });
}

// Reset exclusivo de comunicados
window.resetCommFilters = () => renderCommunications();
