import { showToast } from "./auth.js";

// ✅ NUEVO: Función para actualizar el avatar en el sidebar
function updateSidebarAvatar(imageSrc) {
  const sidebarAvatar = document.getElementById("sidebarAvatar");
  if (sidebarAvatar) {
    sidebarAvatar.src = imageSrc;
  }
}

export function initSettings() {
  // --- Perfil (mostrar datos actuales) ---
  const usernameField = document.getElementById("usernameField");
  const roleField = document.getElementById("roleField");
  const profileImagePreview = document.getElementById("profileImagePreview");
  const profileImageUpload = document.getElementById("profileImageUpload");

  let currentUser = JSON.parse(sessionStorage.getItem("currentUser")) || {
    username: "Invitado",
    role: "Sin rol",
  };

  let allUsers = JSON.parse(localStorage.getItem("users")) || {};

  // Mostrar datos actuales
  usernameField.value = currentUser.username;
  roleField.value = Array.isArray(currentUser.role)
    ? currentUser.role.join(", ")
    : currentUser.role;

  if (currentUser.avatar) {
    profileImagePreview.src = currentUser.avatar;
  }

  // --- Subir nueva imagen ---
  profileImageUpload.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64Image = reader.result;

      currentUser.avatar = base64Image;
      sessionStorage.setItem("currentUser", JSON.stringify(currentUser));

      if (allUsers[currentUser.username]) {
        allUsers[currentUser.username].avatar = base64Image;
        localStorage.setItem("users", JSON.stringify(allUsers));
      }

      // Mostrar en preview y llamar a la nueva función para actualizar el sidebar
      profileImagePreview.src = base64Image;
      updateSidebarAvatar(base64Image); // ✅ NUEVO: Llamar a la función
      showToast("✅ Foto de perfil actualizada", "success");
    };

    reader.readAsDataURL(file);
  });

  // --- Preferencias ---
  const languageSelect = document.getElementById("languageSelect");

  const preferences = JSON.parse(localStorage.getItem("preferences")) || {
    language: "es",
  };

  // Language
  if (languageSelect) {
    languageSelect.value = preferences.language;

    languageSelect.addEventListener("change", () => {
      preferences.language = languageSelect.value;
      localStorage.setItem("preferences", JSON.stringify(preferences));
      showToast(`✅ Idioma cambiado a: ${preferences.language}`, "success");
    });
  }

  // --- Seguridad ---
  const securityForm = document.getElementById("securityForm");
  securityForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const newPassword = document.getElementById("newPassword").value;

    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}/.test(newPassword)) {
      showToast(
        "❌La contraseña debe tener mayúscula, minúscula y número.",
        "error"
      );
      return;
    }

    let userToUpdate = allUsers[currentUser.username];
    if (userToUpdate) {
      userToUpdate.password = newPassword;
      localStorage.setItem("users", JSON.stringify(allUsers));
      showToast("✅ Contraseña actualizada correctamente.", "success");
    } else {
      showToast("❌ Error: Usuario no encontrado para actualizar.", "error");
    }

    securityForm.reset();
  });
}