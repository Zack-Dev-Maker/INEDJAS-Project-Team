import { showToast } from "./auth.js";

// 🎨 Colores por tipo de evento (global)
const tipoEventoColors = {
  "Personal": "#1D4ED8",      // Azul
  "Acto Cultural": "#F59E0B",// Amarillo/Naranja
  "Reunión": "#10B981",       // Verde
  "Recordatorio": "#8B5CF6", // Morado
  "Otro": "#EF4444"          // Rojo
};

// Inicialización del calendario
export function initCalendar() {
  const calendarEl = document.getElementById("calendar");

  if (!calendarEl || calendarEl.offsetHeight === 0) {
    console.warn("⚠ El calendario está oculto o sin altura. No se puede inicializar.");
    return;
  }

  console.log("📆 Inicializando calendario correctamente...");

  window.calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    locale: 'es',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay'
    },
    events: loadEventsFromLocalStorage(),
    eventClick: handleEventClick
  });

  window.calendar.render();
}

// 📦 Cargar eventos desde localStorage
function loadEventsFromLocalStorage() {
  try {
    const eventos = JSON.parse(localStorage.getItem("eventosCalendario") || "[]");
    // Asignar un ID interno si no tiene
    return eventos.map((e, i) => ({ id: e.id || i, ...e })).filter(e => e && e.title && e.start);
  } catch {
    return [];
  }
}

// 📌 Click en evento → abrir modal de detalles
function handleEventClick(info) {
  const eventos = loadEventsFromLocalStorage();
  const index = eventos.findIndex(e => e.id == info.event.id);
  if (index > -1) {
    openEventDetails(eventos[index], index);
  }
}

// Abrir modal de detalles
function openEventDetails(evento, index) {
  document.getElementById("viewEventTitle").textContent = evento.title;
  document.getElementById("viewEventDescription").textContent = evento.description || "Sin descripción";
  document.getElementById("viewEventType").textContent = evento.type || "No especificado";
  document.getElementById("viewEventStart").textContent = formatDateTime(evento.start);
  document.getElementById("viewEventEnd").textContent = evento.end ? formatDateTime(evento.end) : "No especificado";

  document.getElementById("editFromViewBtn").onclick = () => {
    document.getElementById("viewEventModal").classList.add("hidden");
    openEventForm(evento, index);
  };

  document.getElementById("viewEventModal").classList.remove("hidden");
}

// Abrir formulario (nuevo o editar)
function openEventForm(evento = {}, index = "") {
  document.getElementById("editEventIndex").value = index;
  document.getElementById("eventTitle").value = evento.title || "";
  document.getElementById("eventDescription").value = evento.description || "";
  document.getElementById("eventType").value = evento.type || "Personal";
  document.getElementById("eventStart").value = evento.start || "";
  document.getElementById("eventEnd").value = evento.end || "";
  document.getElementById("eventColor").value = evento.color || tipoEventoColors[evento.type] || "#1D4ED8";
  document.getElementById("deleteEventBtn").classList.toggle("hidden", index === "");
  document.getElementById("eventModal").classList.remove("hidden");
}

// Formatear fecha/hora legible
function formatDateTime(dateTime) {
  try {
    const fecha = new Date(dateTime);
    return fecha.toLocaleString("es-ES", { dateStyle: "short", timeStyle: "short" });
  } catch {
    return dateTime;
  }
}

// Listeners DOM
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("eventForm");

  // Guardar evento
  form?.addEventListener("submit", (e) => {
    e.preventDefault();

    const eventos = loadEventsFromLocalStorage();
    const index = document.getElementById("editEventIndex").value;
    const nuevoEvento = {
      id: index !== "" ? eventos[index].id : Date.now(), // ID único
      title: document.getElementById("eventTitle").value.trim(),
      description: document.getElementById("eventDescription").value.trim(),
      type: document.getElementById("eventType").value,
      start: document.getElementById("eventStart").value,
      end: document.getElementById("eventEnd").value,
      color: document.getElementById("eventColor").value
    };

    if (!nuevoEvento.title || !nuevoEvento.start) {
      showToast("❌ Debe tener al menos un título y una fecha de inicio.", "error");
      return;
    }

    if (nuevoEvento.end && new Date(nuevoEvento.end) < new Date(nuevoEvento.start)) {
      showToast("❌ La fecha de fin no puede ser anterior a la de inicio.", "error");
      return;
    }

    if (index !== "") {
      eventos[index] = nuevoEvento;
    } else {
      eventos.push(nuevoEvento);
    }

    localStorage.setItem("eventosCalendario", JSON.stringify(eventos));
    document.getElementById("eventModal").classList.add("hidden");
    window.calendar?.removeAllEvents();
    window.calendar?.addEventSource(loadEventsFromLocalStorage());

    if (index === "") {
    showToast(`✅ Evento "${nuevoEvento.title}" publicado correctamente.`, "success");
    } else {
    showToast(`✏️ Evento "${nuevoEvento.title}" actualizado correctamente.`, "info");
    }

  });

  // Cerrar modal de edición
  document.getElementById("cancelModalBtn")?.addEventListener("click", () => {
    document.getElementById("eventModal").classList.add("hidden");
  });

  // Eliminar evento desde formulario
  document.getElementById("deleteEventBtn")?.addEventListener("click", () => {
    const index = document.getElementById("editEventIndex").value;
    if (index !== "") {
      const eventos = loadEventsFromLocalStorage();
      eventos.splice(index, 1);
      localStorage.setItem("eventosCalendario", JSON.stringify(eventos));
      document.getElementById("eventModal").classList.add("hidden");
      window.calendar?.removeAllEvents();
      window.calendar?.addEventSource(loadEventsFromLocalStorage());
    }
  });

  // Abrir modal de nuevo evento
  document.getElementById("newEventBtn")?.addEventListener("click", () => {
    openEventForm();
    const hoy = new Date().toISOString().split("T")[0];
    document.getElementById("eventStart").value = `${hoy}T08:00`;
    document.getElementById("eventEnd").value = `${hoy}T09:00`;
  });

  // Cerrar modal de detalles
  document.getElementById("closeViewEventBtn")?.addEventListener("click", () => {
    document.getElementById("viewEventModal").classList.add("hidden");
  });
});
