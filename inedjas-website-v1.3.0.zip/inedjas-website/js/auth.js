// ========== ✅ SISTEMA DE TOASTS ==========
export function showToast(message, type = "info") {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.className = "fixed top-5 right-5 z-[9999] flex flex-col gap-2";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `
    px-4 py-2 rounded-lg shadow-md text-white animate-fade-in-down
    ${type === "success" ? "bg-green-600" : ""}
    ${type === "error" ? "bg-red-600" : ""}
    ${type === "warning" ? "bg-yellow-500 text-black" : ""}
    ${type === "info" ? "bg-blue-600" : ""}
  `;
  toast.innerText = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("animate-fade-out");
    setTimeout(() => toast.remove(), 500);
  }, 3000);
}


// ========== ✅ Hashing de Contraseñas ==========
async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint16Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

// ========== ✅ CUENTAS DEV POR DEFECTO ==========
async function ensureDevAccounts() {
  const users = JSON.parse(localStorage.getItem("users") || "{}");
  
  const devAccounts = {
    "MonoDev2025": { password: "proyectoINEDJAS", role: ["Admin", "Dev"] },
    "KenjiroBarros": { password: "proyectoINEDJAS", role: ["Dev"] },
    "EndersonCervera": { password: "proyectoINEDJAS", role: ["Dev"] },
    "MariaMarin": { password: "proyectoINEDJAS", role: ["Dev"] },
    "JhaynerVargas": { password: "proyectoINEDJAS", role: ["Dev"] },
  };

  let needsUpdate = false;
  for (const [username, data] of Object.entries(devAccounts)) {
    if (!users[username]) {
      // ✅ NUEVO: Hasheamos la contraseña antes de guardarla por primera vez
      const hashedPassword = await hashPassword(data.password);
      users[username] = { ...data, password: hashedPassword };
      needsUpdate = true;
    } else {
      // ✅ NUEVO: Si la cuenta ya existe, nos aseguramos de que el hash sea el correcto
      // Esto evita que las contraseñas se re-hasheen cada vez
      const currentHashedPassword = await hashPassword(data.password);
      if (users[username].password !== currentHashedPassword) {
        users[username].password = currentHashedPassword;
        needsUpdate = true;
      }
      
      // Aseguramos que los roles estén bien definidos
      const currentRoles = Array.isArray(users[username].role) ? users[username].role : [users[username].role];
      const requiredRoles = Array.isArray(data.role) ? data.role : [data.role];
      
      let rolesChanged = false;
      requiredRoles.forEach(role => {
        if (!currentRoles.includes(role)) {
          currentRoles.push(role);
          rolesChanged = true;
        }
      });
      
      if (rolesChanged) {
        users[username].role = [...new Set(currentRoles)];
        needsUpdate = true;
      }
    }
  }

  // Si se necesita una actualización, guardamos la lista de usuarios
  if (needsUpdate) {
    localStorage.setItem("users", JSON.stringify(users));
  }
}
ensureDevAccounts();

// ========== ✅ FUNCIÓN DE LOGIN ==========
export async function login() {
  const username = document.getElementById("login-username")?.value.trim();
  const password = document.getElementById("login-password")?.value.trim();

  if (!username || !password) {
    showToast("⚠ Por favor, completa todos los campos.", "warning");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users") || "{}");
  const userData = users[username];
  
  // ✅ MODIFICADO: Comparamos la contraseña hasheada del formulario con la hasheada en localStorage
  if (userData && userData.password === await hashPassword(password)) {
    const roles = Array.isArray(userData.role) ? userData.role : [userData.role];
    const user = { username, role: roles, avatar: userData.avatar, docNumber: userData.docNumber, tipoDoc: userData.tipoDoc };
    
    sessionStorage.setItem("currentUser", JSON.stringify(user));
    
    showToast(`✅ ¡Bienvenido, ${username}!`, "success");
    window.location.href = "pages/home.html";
  } else {
    showToast("❌ Usuario o contraseña incorrectos.", "error");
  }
}

// ========== Helpers de registro y funciones de registro/recuperación sin cambios ==========
export function validarCC(docNumber) {
  if (!/^\d+$/.test(docNumber)) return { valido: false, mensaje: "❌ El documento solo debe contener números." };
  const length = docNumber.length;
  if (length >= 7 && length <= 10) return { valido: true, tipo: "CC" };
  return { valido: false, mensaje: "❌ Cédula de ciudadanía inválida." };
}

function validarDocumentoAvanzado(docNumber, role) {
  switch (role) {
      case "Estudiante":
        if (!/^\d+$/.test(docNumber)) return "❌ El documento solo debe contener números.";
        if (docNumber.length < 10 || docNumber.length > 11) return "❌ Un estudiante debe usar Tarjeta de Identidad (10-11 dígitos).";
        break;
      case "Docente":
      case "Admin":
      case "Dev":
        const ccCheck = validarCC(docNumber);
        if (!ccCheck.valido) {
          return "❌ Debe ingresar una Cédula de Ciudadanía válida (7-10 dígitos).";
        }
        break;
      default:
        return "Rol no válido para registro.";
  }
  return null;
}

function obtenerTipoDocumento(docNumber, role) {
  if (role === "Estudiante") return "TI";
  if (validarCC(docNumber).valido) return "CC";
  return "Desconocido";
}

export async function register() {
  const currentUser = JSON.parse(sessionStorage.getItem("currentUser") || "null");
  const currentRoles = Array.isArray(currentUser?.role) ? currentUser.role : [currentUser?.role];

  if (!currentUser || !currentRoles.some(r => ["Admin", "Dev"].includes(r))) {
    showToast("❌ Solo un Admin o Dev puede crear cuentas nuevas.", "error");
    return;
  }

  const username = document.getElementById("register-username")?.value.trim();
  const password = document.getElementById("register-password")?.value.trim();
  const role = document.getElementById("register-role")?.value;
  const docNumber = document.getElementById("register-doc")?.value.trim();

  if (!username || !password || !role || !docNumber) {
    showToast("⚠ Por favor, completa todos los campos.", "warning");
    return;
  }
  
  const userRegex = /^[a-zA-Z0-9]{4,20}$/;
  if (!userRegex.test(username)) {
      showToast("⚠ Usuario debe tener entre 4-20 caracteres, solo letras y números.", "warning");
      return;
  }
  
  const passRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
  if (!passRegex.test(password)) {
    showToast("⚠ Contraseña: Mínimo 8 caracteres, con mayúscula, minúscula y número.", "warning");
    return;
  }

  const errorDoc = validarDocumentoAvanzado(docNumber, role);
  if (errorDoc) {
    showToast(errorDoc, "error");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users") || "{}");

  if (users[username]) {
    showToast("❌ Ese nombre de usuario ya existe.", "error");
    return;
  }

  for (const user of Object.values(users)) {
    if (user.docNumber === docNumber) {
      showToast("❌ Ese número de documento ya está registrado.", "error");
      return;
    }
  }
  
  const hashedPassword = await hashPassword(password);

  const tipoDoc = obtenerTipoDocumento(docNumber, role);
  users[username] = { password: hashedPassword, role: [role], docNumber, tipoDoc };
  localStorage.setItem("users", JSON.stringify(users));

  showToast(`✅ ¡Cuenta '${username}' creada con éxito!`, "success");

  document.getElementById("register-username").value = '';
  document.getElementById("register-password").value = '';
  document.getElementById("register-doc").value = '';
  document.getElementById("login-section").classList.remove("hidden");
  document.getElementById("register-section").classList.add("hidden");
}

export function recoverPassword() {
  showToast("❔ Función de recuperación de contraseña aún no implementada.", "info");
}

export function resetPassword() {
  showToast("❔ Función de restablecimiento de contraseña aún no implementada.", "info");
}