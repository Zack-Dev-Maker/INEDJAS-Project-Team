// =======================
// 📦 Imports
// =======================
import { login, register, recoverPassword, showToast } from "./auth.js";
import { mostrarLogin, mostrarRegistro } from "./dom.js";
import { initCalendar } from "./calendar.js";
import { initContactForm } from "./contact.js";
import { renderNews, setupNewsFilters, initNewsForm, renderCommunications, setupCommunicationFilters, initCommunicationsForm } from "./utils.js";
import { initSettings } from "./settings.js";
import { initDeleteAccounts } from "./deleteAccounts.js";
import { initTheme } from "./theme.js";
import { initSidebar } from "./sidebar.js";

// =======================
// 🚀 Inicialización principal
// =======================
document.addEventListener("DOMContentLoaded", () => {
  // =======================
  // ⏳ Preloader
  // =======================
  const preloader = document.getElementById("preloader");
  window.addEventListener("load", () => {
    if (!preloader) return;
    setTimeout(() => {
      preloader.style.transition = "opacity 0.5s ease";
      preloader.style.opacity = "0";
      preloader.addEventListener("transitionend", () => preloader.remove(), { once: true });
    }, 300);
  });

  console.log("✅ DOM cargado. Path:", window.location.pathname);

  // ✅ NUEVO: Inicializar tema
  initTheme();

  // =======================
  // 🔑 Usuario
  // =======================
  // ✅ MODIFICADO: Leemos de sessionStorage
  let currentUser = JSON.parse(sessionStorage.getItem("currentUser") || "null");
  const allUsers = JSON.parse(localStorage.getItem("users") || "{}");

  if (currentUser && allUsers[currentUser.username]) {
    // 🔄 Actualizar currentUser con la info más reciente de users
    currentUser = { ...allUsers[currentUser.username], ...currentUser };
    // ✅ MODIFICADO: Guardamos de nuevo en sessionStorage
    sessionStorage.setItem("currentUser", JSON.stringify(currentUser));
  }

  const isInRoot = !window.location.pathname.includes("/pages/");
  const basePath = isInRoot ? "pages/" : "../";  

  function renderUserInfo(user) {
    // Hero (Bienvenida)
    const heroUsernameEl = document.getElementById("heroUsername");
    const heroRoleEl = document.getElementById("heroUserRole");

    if (heroUsernameEl) heroUsernameEl.textContent = user.username || "Invitado";
    if (heroRoleEl) {
      heroRoleEl.textContent = Array.isArray(user.role) ? user.role.join(", ") : user.role || "Sin rol";
    }
  }

  if (currentUser) {
    renderUserInfo(currentUser);
  } else {
    renderUserInfo({ username: "Invitado", role: "Sin rol" });
  }

  // =======================
  // 👥 Login / Registro
  // =======================
  const addBtn = document.getElementById("addAccountBtn");
  const deleteBtn = document.getElementById("deleteAccountBtn");
  const registerSection = document.getElementById("register-section");
  const loginSection = document.getElementById("login-section");

  if (currentUser?.role && Array.isArray(currentUser.role) && currentUser.role.some(r => ["Admin", "Dev"].includes(r))) {
    addBtn?.classList.remove("hidden");
    deleteBtn?.classList.remove("hidden");

    // 👉 Si estamos en home.html, redirigir a index con sección register
    if (window.location.pathname.includes("home.html")) {
      addBtn?.addEventListener("click", (e) => {
        e.preventDefault();
        window.location.href = basePath + "index.html?section=register";
      });
    }

    // 👉 Si estamos en index.html, mostrar directamente la sección de registro
    if (window.location.pathname.includes("index.html") && registerSection && loginSection) {
      addBtn?.addEventListener("click", (e) => {
        e.preventDefault();
        loginSection.classList.add("hidden");
        registerSection.classList.remove("hidden");
      });
    }
  }

  // Mostrar registro directo si viene en la URL
  const params = new URLSearchParams(window.location.search);
  if (params.get("section") === "register" && registerSection && loginSection) {
    loginSection.classList.add("hidden");
    registerSection.classList.remove("hidden");
  }

  // Eventos básicos
  // MODIFICADO: Añadimos async a la función anónima para que espere a login()
    document.getElementById("login-btn")?.addEventListener("click", async () => {
    await login();
  });
  // MODIFICADO: Añadimos async a la función anónima para que espere a register()
    document.getElementById("register-btn")?.addEventListener("click", async () => {
    await register();
  });
  document.getElementById("recover-btn")?.addEventListener("click", (e) => {
    e.preventDefault();
    recoverPassword();
  });

  document.getElementById("link-to-register")?.addEventListener("click", (e) => {
    e.preventDefault();
    mostrarRegistro();
  });

  document.getElementById("link-to-login")?.addEventListener("click", (e) => {
    e.preventDefault();
    mostrarLogin();
  });

  // ✅ MODIFICADO: Ahora borra de sessionStorage y redirige a la página de logout
  document.getElementById("logoutBtn")?.addEventListener("click", () => {
    sessionStorage.removeItem("currentUser");
    window.location.href = basePath + "logout.html";
  });

  // =======================
  // 📰 Noticias
  // =======================
  const newsContainer = document.getElementById("news-container");
  const newsSection = document.getElementById("news-form-section");
  const emptyState = document.getElementById("empty-state");
  const filterButtons = document.querySelectorAll(".filter-btn");
  const newsForm = document.getElementById("newsForm");
  
  // ✅ NUEVO: La función de filtrado se encuentra en utils.js
  if (filterButtons.length > 0) {
    setupNewsFilters();
  }

  if (newsForm) initNewsForm(showToast);
  
  if (newsContainer) {
    renderNews();
    if (newsSection && currentUser?.role?.includes("Admin")) newsSection.classList.remove("hidden");
  }

  // =======================
  // 📣 Comunicados
  // =======================
  const communicationsContainer = document.getElementById("communications-container");
  const commForm = document.getElementById("communicationsForm");
  const communicationsSection = document.getElementById("communications-form-section");
  const studentMsg = document.getElementById("student-msg");
  const teacherMsg = document.getElementById("teacher-msg");
  
  // Mostrar formulario solo para Admin/Dev
  if (currentUser?.role && Array.isArray(currentUser.role) && currentUser.role.some(r => ["Admin", "Dev"].includes(r))) {
    if (communicationsSection) communicationsSection.classList.remove("hidden");
  } else {
    // Mostrar mensajes para estudiantes/docentes
    if (studentMsg && currentUser?.role?.includes("Estudiante")) studentMsg.classList.remove("hidden");
    if (teacherMsg && currentUser?.role?.includes("Docente")) teacherMsg.classList.remove("hidden");
  }

  // Renderizar comunicados y filtros
  if (communicationsContainer) {
    renderCommunications();
    setupCommunicationFilters();
  }

  // Inicializar formulario si existe
  if (commForm) {
    initCommunicationsForm(showToast);
  }

  // =======================
  // 📞 Contacto
  // =======================
  if (document.getElementById("contactForm")) initContactForm();

  // =======================
  // 📅 Calendario
  // =======================
  const calendarEl = document.getElementById("calendar");
  if (calendarEl) {
    calendarEl.style.height = "600px";
    const style = getComputedStyle(calendarEl);
    const isHidden = style.display === "none" || style.visibility === "hidden" || calendarEl.offsetHeight === 0;
    if (!isHidden) initCalendar();
  }

  // =======================
  // ⚙️ Configuraciones
  // =======================
  if (window.location.pathname.includes("settings.html")) {
    initSettings();
  }

  // =======================
  // 🗑️ Eliminar cuentas
  // =======================
  if (window.location.pathname.includes("deleteAccounts.html")) {
    initDeleteAccounts();
  }

  // =======================
  // 📂 Sidebar
  // =======================
initSidebar();
});

// =======================
// 📱 Navegación móvil
// =======================
const navToggle = document.getElementById('nav-toggle');
const mobileMenu = document.getElementById('mobile-menu');

navToggle?.addEventListener('click', () => {
  if (mobileMenu.style.maxHeight && mobileMenu.style.maxHeight !== "0px") {
    mobileMenu.style.maxHeight = "0px"; // cerrar
  } else {
    mobileMenu.style.maxHeight = mobileMenu.scrollHeight + "px"; // abrir
  }
});

// =======================
// 🎮 Konami Code para mostrar rol Dev
// =======================
const konamiCode = [
  "ArrowUp","ArrowUp","ArrowDown","ArrowDown",
  "ArrowLeft","ArrowRight","ArrowLeft","ArrowRight",
  "b","a"
];
let konamiIndex = 0;

document.addEventListener("keydown", (e) => {
  if (e.key === konamiCode[konamiIndex]) {
    konamiIndex++;
    if (konamiIndex === konamiCode.length) {
      const devOption = document.querySelector("#register-role option[value='Dev']");
      if (devOption) {
        devOption.classList.remove("hidden");
        showToast("¡Modo Dev activado! Ahora puedes seleccionar el rol Dev.", "success");
      }
      konamiIndex = 0; // reiniciar
    }
  } else {
    konamiIndex = 0; // reset si falla la secuencia
  }
});