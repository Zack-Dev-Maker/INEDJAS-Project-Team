// =======================
// sidebar.js
// =======================

export function initSidebar() {
  const sidebar = document.getElementById("sidebar");
  const openSidebarBtn = document.getElementById("openSidebarBtn");
  const closeSidebarBtn = document.getElementById("closeSidebarBtn");
  const sidebarUsername = document.getElementById("username");
  const sidebarRole = document.getElementById("userRole");
  const sidebarAvatar = document.getElementById("sidebarAvatar");
  
  const addAccountBtn = document.getElementById("addAccountBtn");
  const deleteAccountBtn = document.getElementById("deleteAccountBtn");

  // Leer el usuario actual desde sessionStorage
  const currentUser = JSON.parse(sessionStorage.getItem("currentUser") || "null");
  
  // Ruta base
  const isInRoot = !window.location.pathname.includes("/pages/");
  const basePath = isInRoot ? "pages/" : "../";

  // 1. Mostrar información del usuario en el sidebar
  if (currentUser) {
    sidebarUsername.textContent = currentUser.username || "Invitado";
    sidebarRole.textContent = Array.isArray(currentUser.role) ? currentUser.role.join(", ") : currentUser.role || "Sin rol";
    sidebarAvatar.src = currentUser.avatar || `${basePath}assets/user_default.png`;
  } else {
    sidebarUsername.textContent = "Invitado";
    sidebarRole.textContent = "Sin rol";
    sidebarAvatar.src = `${basePath}assets/user_default.png`;
  }

  // 2. Controlar la visibilidad de los botones de admin
  if (currentUser?.role && currentUser.role.some(r => ["Admin", "Dev"].includes(r))) {
    if (addAccountBtn) addAccountBtn.classList.remove("hidden");
    if (deleteAccountBtn) deleteAccountBtn.classList.remove("hidden");
  }

  // 3. Controlar la apertura y cierre del sidebar
  openSidebarBtn?.addEventListener("click", () => {
    sidebar.classList.remove("translate-x-full");
  });

  closeSidebarBtn?.addEventListener("click", () => {
    sidebar.classList.add("translate-x-full");
  });
}