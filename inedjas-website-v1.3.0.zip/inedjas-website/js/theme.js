// =======================
// theme.js
// =======================

import { showToast } from "./auth.js";

export function initTheme() {
  // Obtener preferencias del localStorage o usar valores por defecto
  const preferences = JSON.parse(localStorage.getItem("preferences")) || {
    darkMode: false,
  };

  const darkModeToggle = document.getElementById("darkModeToggle");

  if (!darkModeToggle) return; // si el toggle no existe, no sigas

  // Aplicar la preferencia de tema al cargar
  if (preferences.darkMode) {
    document.documentElement.classList.add("dark");
    darkModeToggle.checked = true;
  } else {
    document.documentElement.classList.remove("dark");
    darkModeToggle.checked = false;
  }

  // Escuchar cambios
  darkModeToggle.addEventListener("change", () => {
    preferences.darkMode = darkModeToggle.checked;
    localStorage.setItem("preferences", JSON.stringify(preferences));

    if (darkModeToggle.checked) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }

    if (typeof showToast === "function") {
      showToast(
        `❔ Modo ${darkModeToggle.checked ? "oscuro en desarrollo" : "claro estable"}`,
        "info"
      );
    }
  });
}
