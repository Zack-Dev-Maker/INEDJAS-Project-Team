import { login, register, recoverPassword } from "./auth.js";
import { mostrarLogin, mostrarRegistro, renderUserInfo } from "./dom.js";
import { initCalendar } from "./calendar.js";
import { initContactForm } from "./contact.js";
import { initNewsForm, renderNews } from "./utils.js";

document.addEventListener("DOMContentLoaded", () => {
  console.log("✅ DOM completamente cargado. Path:", window.location.pathname);

  // 📂 Detección de basePath
  const isInRoot = !window.location.pathname.includes("/pages/");
  const basePath = isInRoot ? "pages/" : "../";

  // 👤 Usuario actual
  const currentUser = JSON.parse(localStorage.getItem("currentUser") || "null");
  console.log("🔎 Usuario detectado:", currentUser);

  // 🔐 Recuperar contraseña
  document.getElementById("recover-btn")?.addEventListener("click", (e) => {
    e.preventDefault();
    recoverPassword();
  });

  // 🔐 Protección de rutas privadas
  if (!isInRoot && (!currentUser?.username || !currentUser?.role)) {
    alert("Debes iniciar sesión primero.");
    window.location.href = basePath + "start.html";
    return;
  }

  // 🔄 Logout
  document.getElementById("logoutBtn")?.addEventListener("click", () => {
    localStorage.removeItem("currentUser");
    window.location.href = basePath + "index.html";
  });

  // 🔑 Login & Registro
  document.getElementById("login-btn")?.addEventListener("click", login);
  document.getElementById("register-btn")?.addEventListener("click", register);

  // 🔄 Cambio entre formularios
  document.getElementById("link-to-register")?.addEventListener("click", (e) => {
    e.preventDefault();
    mostrarRegistro();
  });
  document.getElementById("link-to-login")?.addEventListener("click", (e) => {
    e.preventDefault();
    mostrarLogin();
  });

  // 📰 Noticias (solo mostrar si hay sección)
  const newsSection = document.getElementById("news-form-section");
  if (newsSection) {
    newsSection.classList.remove("hidden");

    if (document.getElementById("newsForm")) {
      console.log("🗞️ Inicializando formulario de noticias...");
      initNewsForm();
    }
  }

  // 📞 Formulario de contacto
  if (document.getElementById("contactForm")) {
    console.log("📬 Inicializando formulario de contacto...");
    initContactForm();
  }

  // 📅 Calendario
  const calendarEl = document.getElementById("calendar");
  if (calendarEl) {
    calendarEl.style.height = "600px";

    const style = getComputedStyle(calendarEl);
    const isHidden =
      style.display === "none" ||
      style.visibility === "hidden" ||
      calendarEl.offsetHeight === 0;

    if (isHidden) {
      console.warn("⚠️ El calendario está oculto o sin altura. No se puede inicializar.");
    } else {
      console.log("📅 Inicializando calendario correctamente...");
      initCalendar();
    }
  }

  // 🙋 Renderizar usuario y noticias
  if (currentUser) {
  renderUserInfo(currentUser);
  }
  renderNews();
});
