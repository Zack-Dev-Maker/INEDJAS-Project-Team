// Contenedor donde se mostrarán las noticias
export const newsContainer = document.getElementById("news-container");

// Lista de noticias almacenadas en LocalStorage
export const storedNews = JSON.parse(localStorage.getItem("newsList")) || [];

/**
 * Crea una tarjeta de noticia
 * @param {Object} param0 - Datos de la noticia
 * @param {string} param0.title - Título
 * @param {string} param0.content - Contenido
 * @param {string} param0.category - Categoría (blue, green, purple)
 * @param {number} param0.timestamp - Marca de tiempo
 * @returns {HTMLElement} Tarjeta de noticia lista para insertar en el DOM
 */
export function createNewsCard({ title, content, category, timestamp }) {
  const categoryColors = {
    blue: "bg-blue-100 text-blue-900 border-blue-300",
    green: "bg-green-100 text-green-900 border-green-300",
    purple: "bg-purple-100 text-purple-900 border-purple-300",
  };

  const date = new Date(timestamp).toLocaleString();

  const card = document.createElement("div");
  card.className = `border-l-4 p-4 rounded shadow ${categoryColors[category] || categoryColors.blue}`;

  card.innerHTML = `
    <h4 class="text-xl font-semibold">${title}</h4>
    <p class="text-sm mt-1 mb-2 text-gray-700">${content}</p>
    <div class="text-xs text-gray-500">${date}</div>
  `;

  return card;
}

/**
 * Renderiza las noticias en pantalla desde la más reciente
 */
export function renderNews() {
  if (!newsContainer) {
    console.warn("⚠️ No se encontró el contenedor de noticias.");
    return;
  }

  newsContainer.innerHTML = "";

  // Mostrar la más reciente primero
  const sortedNews = [...storedNews].sort((a, b) => b.timestamp - a.timestamp);

  if (sortedNews.length === 0) {
    newsContainer.innerHTML = `<p class="text-gray-500 text-center">No hay noticias publicadas.</p>`;
    return;
  }

  sortedNews.forEach(news => {
    const card = createNewsCard(news);
    newsContainer.appendChild(card);
  });
}

/**
 * Inicializa el formulario para publicar noticias
 */
export function initNewsForm() {
  const newsForm = document.getElementById("newsForm");

  if (!newsForm) {
    console.warn("⚠️ No se encontró el formulario de noticias.");
    return;
  }

  newsForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const title = document.getElementById("newsTitle")?.value.trim();
    const content = document.getElementById("newsContent")?.value.trim();
    const category = document.getElementById("newsCategory")?.value;

    if (!title || !content) {
      alert("Por favor, completa todos los campos.");
      return;
    }

    const newEntry = {
      title,
      content,
      category,
      timestamp: Date.now()
    };

    storedNews.unshift(newEntry);
    localStorage.setItem("newsList", JSON.stringify(storedNews));

    renderNews();
    newsForm.reset();

    alert("✅ ¡Noticia publicada con éxito!");
  });
}
