export function login() {
  const username = document.getElementById("login-username")?.value.trim();
  const password = document.getElementById("login-password")?.value.trim();

  if (!username || !password) {
    alert("Por favor, completa todos los campos.");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users") || "{}");
  const userData = users[username];

  if (userData && userData.password === password) {
    const user = { username, role: userData.role };
    localStorage.setItem("currentUser", JSON.stringify(user));
    window.location.href = "pages/home.html";
  } else {
    alert("Usuario o contraseña incorrectos.");
  }
}

export function register() {
  const username = document.getElementById("register-username")?.value.trim();
  const password = document.getElementById("register-password")?.value.trim();
  const role = document.getElementById("register-role")?.value;

  if (!username || !password || !role) {
    alert("Por favor, completa todos los campos.");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users") || "{}");

  if (users[username]) {
    alert("Ese usuario ya existe.");
    return;
  }

  users[username] = { password, role };
  localStorage.setItem("users", JSON.stringify(users));
  localStorage.setItem("currentUser", JSON.stringify({ username, role }));

  alert("¡Usuario registrado con éxito!");

  import("./dom.js").then((mod) => {
    if (typeof mod.mostrarLogin === "function") {
      mod.mostrarLogin();
    }
  });
}

export function deleteAccount() {
  const user = JSON.parse(localStorage.getItem("currentUser") || "null");
  if (!user?.username) {
    alert("No hay ninguna cuenta activa para eliminar.");
    return;
  }

  const confirmation = confirm(`¿Eliminar la cuenta '${user.username}'? Esta acción no se puede deshacer.`);
  if (!confirmation) return;

  const users = JSON.parse(localStorage.getItem("users") || "{}");
  delete users[user.username];

  localStorage.setItem("users", JSON.stringify(users));
  localStorage.removeItem("currentUser");

  alert("Cuenta eliminada.");
  window.location.href = "../index.html";
}
