// ✅ Crea las cuentas Dev si no existen y asegura que MonoDev2025 sea Admin + Dev
function ensureDevAccounts() {
  const users = JSON.parse(localStorage.getItem("users") || "{}");

  const devAccounts = {
    "MonoDev2025": "proyectoINEDJAS",
    "KenjiroBarros": "proyectoINEDJAS",
    "EndersonCervera": "proyectoINEDJAS",
    "MariaMarin": "proyectoINEDJAS",
  };

  for (const [username, password] of Object.entries(devAccounts)) {
    if (!users[username]) {
      users[username] = { password, role: ["Dev"] };
    } else {
      // Si ya existe, aseguramos que MonoDev2025 tenga ambos roles
      if (username === "MonoDev2025") {
        const currentRoles = Array.isArray(users[username].role) ? users[username].role : [users[username].role];
        if (!currentRoles.includes("Dev")) currentRoles.push("Dev");
        if (!currentRoles.includes("Admin")) currentRoles.push("Admin");
        users[username].role = currentRoles;
      }
    }
  }

  localStorage.setItem("users", JSON.stringify(users));
}

ensureDevAccounts();

// Helper para redirigir correctamente al index desde / o /pages/
function goToIndex() {
  const isInRoot = !window.location.pathname.includes("/pages/");
  window.location.href = isInRoot ? "index.html" : "../index.html";
}

// ✅ Ajuste de login para múltiples roles
export function login() {
  const username = document.getElementById("login-username")?.value.trim();
  const password = document.getElementById("login-password")?.value.trim();

  if (!username || !password) {
    alert("Por favor, completa todos los campos.");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users") || "{}");
  const userData = users[username];

  if (userData && userData.password === password) {
    const roles = Array.isArray(userData.role) ? userData.role : [userData.role];
    const user = { username, role: roles };
    localStorage.setItem("currentUser", JSON.stringify(user));
    window.location.href = "pages/home.html";
  } else {
    alert("Usuario o contraseña incorrectos.");
  }
}

// ✅ Ajuste de register para múltiples roles
export function register() {
  const currentUser = JSON.parse(localStorage.getItem("currentUser") || "null");
  const currentRoles = Array.isArray(currentUser?.role) ? currentUser.role : [currentUser?.role];
  
  if (!currentUser || !currentRoles.some(r => ["Admin", "Dev"].includes(r))) {
    alert("Solo un Admin o Dev puede crear cuentas nuevas.");
    return;
  }

  const username = document.getElementById("register-username")?.value.trim();
  const password = document.getElementById("register-password")?.value.trim();
  const role = document.getElementById("register-role")?.value;

  if (!username || !password || !role) {
    alert("Por favor, completa todos los campos.");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users") || "{}");

  if (users[username]) {
    alert("Ese usuario ya existe.");
    return;
  }

  // Guardamos role como array para consistencia
  users[username] = { password, role: [role] };
  localStorage.setItem("users", JSON.stringify(users));

  alert(`¡Cuenta '${username}' creada con éxito por ${currentUser.username}!`);

  import("./dom.js").then((mod) => {
    if (typeof mod.mostrarLogin === "function") mod.mostrarLogin();
  });
}

// ✅ Recuperar y restablecer contraseña (igual, compatible con roles array)
export function recoverPassword() { /* ...igual que antes... */ }
export function resetPassword() { /* ...igual que antes... */ }

export function deleteAccount() {
  const user = JSON.parse(localStorage.getItem("currentUser") || "null");
  const userRoles = Array.isArray(user?.role) ? user.role : [user?.role];

  if (!user?.username) {
    alert("No hay ninguna cuenta activa para eliminar.");
    return;
  }

  if (user.username === "MonoDev2025" && userRoles.includes("Dev")) {
    alert("⚠️ La cuenta Dev principal no puede eliminarse.");
    return;
  }

  const confirmation = confirm(
    `¿Eliminar la cuenta '${user.username}'? Esta acción no se puede deshacer.`
  );
  if (!confirmation) return;

  const users = JSON.parse(localStorage.getItem("users") || "{}");
  delete users[user.username];

  localStorage.setItem("users", JSON.stringify(users));
  localStorage.removeItem("currentUser");

  alert("Cuenta eliminada.");
  goToIndex();
}
